import { cn } from "@/lib/utils";

interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary";
}

export default function Button({
  variant = "primary",
  className,
  children,
  ...props
}: ButtonProps) {
  return (
    <button
      className={cn(
        "inline-flex h-14 items-center justify-center rounded-full px-10 text-[18px] font-semibold transition-all duration-300",

        variant === "primary"
          ? "bg-[linear-gradient(90deg,#4f1d95_0%,#0b0b0b_25%,#0b0b0b_100%)] text-white shadow-lg hover:-translate-y-0.5 hover:shadow-xl"
          : "border border-neutral-200 bg-white text-black shadow-sm hover:shadow-md",

        className
      )}
      {...props}
    >
      <span className="flex items-center gap-3">
        {children}
        <span className="text-lg">→</span>
      </span>
    </button>
  );
}